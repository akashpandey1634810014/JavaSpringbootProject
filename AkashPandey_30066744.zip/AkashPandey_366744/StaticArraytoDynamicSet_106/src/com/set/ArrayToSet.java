package com.set;

import java.util.HashSet;
public class ArrayToSet implements MySet {
   HashSet<String> arrayToSet;
   public ArrayToSet() {
       arrayToSet = new HashSet<>();
   }
   @Override
   public void convert(String[] a) throws InvalidCharacterException {
       for (String s : a) {
           if (!s.matches("[a-zA-Z0-9]+")) {
               throw new InvalidCharacterException("Invalid characters in string: " + s);
           }
           if (arrayToSet.contains(s)) {
               System.out.println("The string: " + s + " is a duplicate and was not added");
           } else {
               arrayToSet.add(s);
               System.out.println("I have added the string: " + s + " to the set");
           }
       }
   }
   @Override
   public void remove(String s) {
       if (arrayToSet.contains(s)) {
           arrayToSet.remove(s);
           System.out.println("I have removed the string: " + s + " from the set");
       } else {
           System.out.println("The string: " + s + " does not exist in the set");
       }
   }
   @Override
   public HashSet<String> compact() {
       arrayToSet.removeIf(s -> Character.isDigit(s.charAt(0)));
       return arrayToSet;
   }
}