package com.set;

import java.util.*;
public class Main {
   public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       int n = Integer.parseInt(sc.nextLine());
       String[] inputArray = new String[n];
       for (int i = 0; i < n; i++) {
           inputArray[i] = sc.nextLine().trim();
       }
       int x = Integer.parseInt(sc.nextLine());
       String[] toRemove = new String[x];
       for (int i = 0; i < x; i++) {
           toRemove[i] = sc.nextLine().trim();
       }
       ArrayToSet set = new ArrayToSet();
       try {
           set.convert(inputArray);
       } catch (InvalidCharacterException e) {
           System.out.println(e.getMessage());
       }
       for (String s : toRemove) {
           set.remove(s);
       }
       HashSet<String> compacted = set.compact();
       System.out.println("Final compacted set: " + compacted);
       sc.close();
   }
}
