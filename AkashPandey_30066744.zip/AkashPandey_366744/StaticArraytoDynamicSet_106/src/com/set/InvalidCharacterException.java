package com.set;

public class InvalidCharacterException extends Exception {
	   public InvalidCharacterException(String s) {
	       super(s);
	   }
	}