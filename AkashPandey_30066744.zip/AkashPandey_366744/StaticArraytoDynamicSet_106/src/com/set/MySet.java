package com.set;

import java.util.HashSet;
public interface MySet {
   void convert(String[] a) throws InvalidCharacterException;
   void remove(String s);
   HashSet<String> compact();
}
