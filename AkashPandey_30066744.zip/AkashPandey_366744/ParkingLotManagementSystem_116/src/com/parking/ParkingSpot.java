package com.parking;
import java.util.*;
public class ParkingSpot {
   private int id;
   private int capacity;
   private Set<Vehicle> parkedVehicles = new HashSet<>();
   private Queue<Vehicle> waitingList = new LinkedList<>();
   public ParkingSpot(int id, int capacity) {
this.id = id;
       this.capacity = capacity;
   }
   public int getId() {
       return id;
   }
   public void parkVehicle(Vehicle vehicle) {
       if (parkedVehicles.size() < capacity) {
           parkedVehicles.add(vehicle);
           System.out.println("Vehicle " + vehicle.getNumber() + " has parked in Spot " + id + ".");
       } else {
           waitingList.offer(vehicle);
           System.out.println("No available spots. Vehicle " + vehicle.getNumber() + " has been added to the waiting list for Spot " + id + ".");
       }
   }
   public void leaveVehicle(Vehicle vehicle) {
       if (parkedVehicles.remove(vehicle)) {
           System.out.println("Vehicle " + vehicle.getNumber() + " has left Spot " + id + ".");
           if (!waitingList.isEmpty()) {
               Vehicle nextVehicle = waitingList.poll();
               parkedVehicles.add(nextVehicle);
               System.out.println("Vehicle " + nextVehicle.getNumber() + " has parked in Spot " + id + ".");
           }
       }
   }
   public boolean isVehicleParked(Vehicle vehicle) {
       return parkedVehicles.contains(vehicle);
   }
}
