package com.parking;
public class Main {
	   public static void main(String[] args) {
	       ParkingLot parkingLot = new ParkingLot();
	       // Sample data setup
	       parkingLot.addVehicle(new Vehicle(1, "KA01AB1234"));
	       parkingLot.addVehicle(new Vehicle(2, "KA01AB5678"));
	       parkingLot.addVehicle(new Vehicle(3, "KA01AB9999"));
	       parkingLot.addSpot(new ParkingSpot(101, 1));  // Only 1 vehicle can park
	       parkingLot.addSpot(new ParkingSpot(102, 2));  // Can park 2 vehicles
	       // Parking sequence
	       parkingLot.parkVehicle(1, 101);
	       parkingLot.parkVehicle(2, 101);  // should go to waiting list
	       parkingLot.parkVehicle(3, 101);  // should go to waiting list
	       // Vehicle 1 leaves
	       parkingLot.leaveVehicle(1, 101); // should free space for vehicle 2
	       // Vehicle 2 leaves
	       parkingLot.leaveVehicle(2, 101); // should free space for vehicle 3
	   }
	}
