package com.parking;
import java.util.*;
public class ParkingLot {
   private Map<Integer, ParkingSpot> spots = new HashMap<>();
   private Map<Integer, Vehicle> vehicles = new HashMap<>();
   public void addSpot(ParkingSpot parkingSpot) {
       spots.put(parkingSpot.getId(), parkingSpot);
   }
   public void addVehicle(Vehicle vehicle) {
       vehicles.put(vehicle.getId(), vehicle);
   }
   public void parkVehicle(int vehicleId, int spotId) {
       Vehicle vehicle = vehicles.get(vehicleId);
       ParkingSpot spot = spots.get(spotId);
       if (vehicle != null && spot != null) {
           vehicle.park(spot);
       }
   }
   public void leaveVehicle(int vehicleId, int spotId) {
       Vehicle vehicle = vehicles.get(vehicleId);
       ParkingSpot spot = spots.get(spotId);
       if (vehicle != null && spot != null) {
           vehicle.leave(spot);
       }
   }
}
