package com.parking;
public class Vehicle {

    private int id;

    private String number;

    public Vehicle(int id, String number) {
this.id = id;

        this.number = number;

    }

    public int getId() {

        return id;

    }

    public String getNumber() {

        return number;

    }

    public void park(ParkingSpot parkingSpot) {

        parkingSpot.parkVehicle(this);

    }

    public void leave(ParkingSpot parkingSpot) {

        parkingSpot.leaveVehicle(this);

    }

}
 
