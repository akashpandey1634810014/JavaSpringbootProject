package com.library;
public class FictionSection implements Library {
	   int[] bookPages;
	   public FictionSection(int books) {
	       bookPages = new int[books];
	       for (int i = 0; i < books; i++) {
	           bookPages[i] = 0;
	       }
	   }
	   @Override
	   public void addBooks(int[] books) {
	       int length = Math.min(bookPages.length, books.length);
	       for (int i = 0; i < length; i++) {
	           bookPages[i] = books[i];
	       }
	       System.out.println("Books for Fiction section processed");
	   }
	   @Override
	   public void averagePages() {
	       int sum = 0;
	       for (int page : bookPages) {
	           sum += page;
	       }
	       double avg = (double) sum / bookPages.length;
	       System.out.printf("Average pages in Fiction section is %.2f%n", avg);
	   }
	   @Override
	   public void maxPages() {
	       int max = Integer.MIN_VALUE;
	       for (int page : bookPages) {
	           max = Math.max(max, page);
	       }
	       System.out.println("Maximum pages in Fiction section is " + max);
	   }
	   @Override
	   public void minPages() {
	       int min = Integer.MAX_VALUE;
	       for (int page : bookPages) {
	           min = Math.min(min, page);
	       }
	       System.out.println("Minimum pages in Fiction section is " + min);
	   }
	}
