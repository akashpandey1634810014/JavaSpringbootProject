package com.library;
public interface Library {
	   void addBooks(int[] books);
	   void averagePages();
	   void maxPages();
	   void minPages();
	}
