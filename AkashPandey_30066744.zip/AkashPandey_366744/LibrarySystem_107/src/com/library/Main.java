package com.library;
import java.util.*;
public class Main {
   public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       // Read number of books for each section
       int n = sc.nextInt(); // Fiction
       int m = sc.nextInt(); // Non-Fiction
       int[] fictionBooks = new int[n];
       for (int i = 0; i < n; i++) {
           fictionBooks[i] = sc.nextInt();
       }
       int[] nonFictionBooks = new int[m];
       for (int i = 0; i < m; i++) {
           nonFictionBooks[i] = sc.nextInt();
       }
       FictionSection fiction = new FictionSection(n);
       NonFictionSection nonFiction = new NonFictionSection(m);
       fiction.addBooks(fictionBooks);
       fiction.averagePages();
       fiction.maxPages();
       fiction.minPages();
       nonFiction.addBooks(nonFictionBooks);
       nonFiction.averagePages();
       nonFiction.maxPages();
       nonFiction.minPages();
       sc.close();
   }
}
