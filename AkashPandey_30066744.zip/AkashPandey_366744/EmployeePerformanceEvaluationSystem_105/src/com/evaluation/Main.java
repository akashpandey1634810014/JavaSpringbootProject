package com.evaluation;
import java.util.*;
class Employee {
   String name;
   String department;
   float performanceScore;
   Employee(String name, String department) {
       this.name = name;
       this.department = department;
       System.out.println("Added employee: " + name + " to the " + department + " department");
   }
   String getName() {
       return name;
   }
   String evaluatePerformance() {
       if (performanceScore >= 50.0) {
           String msg = name + " has been awarded a bonus in the " + department + " department";
           System.out.println(msg);
           return msg;
       } else {
           String msg = name + " needs improvement in the " + department + " department";
           System.out.println(msg);
           return msg;
       }
   }
}
class PerformanceReview extends Employee {
   Integer task1, task2, task3;
   PerformanceReview(int t1, int t2, int t3, String name, String department) {
       super(name, department);
       this.task1 = t1;
       this.task2 = t2;
       this.task3 = t3;
       System.out.println(name + " scored " + task1 + " in task1");
       System.out.println(name + " scored " + task2 + " in task2");
       System.out.println(name + " scored " + task3 + " in task3");
   }
   String calculatePerformance() {
       performanceScore = ((task1 + task2 + task3) * 100.0f) / 300;
       return evaluatePerformance();
   }
   String adjustTaskScore(int newScore, String task) {
       System.out.println(name + " requested a review for " + task);
       switch (task) {
           case "task1":
               task1 = newScore;
               break;
           case "task2":
               task2 = newScore;
               break;
           case "task3":
               task3 = newScore;
               break;
           default:
               System.out.println("Invalid task");
               return "Invalid task";
       }
       performanceScore = ((task1 + task2 + task3) * 100.0f) / 300;
       String result = evaluatePerformance();
       System.out.println("Updated performance: " + result);
       return result;
   }
}
public class Main {
   public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       // Read employee names
       String[] names = sc.nextLine().split(" ");
       // Read employee departments
       String[] departments = sc.nextLine().split(" ");
       // Create array of PerformanceReview
       PerformanceReview[] employees = new PerformanceReview[5];
       for (int i = 0; i < 5; i++) {
           int t1 = sc.nextInt();
           int t2 = sc.nextInt();
           int t3 = sc.nextInt();
           sc.nextLine(); // consume newline
           employees[i] = new PerformanceReview(t1, t2, t3, names[i], departments[i]);
           employees[i].calculatePerformance();
       }
       // Read task for review
       String reviewTask = sc.nextLine();
       // Adjust task score for demonstration (e.g., assume update to 80)
       employees[0].adjustTaskScore(80, reviewTask);
       sc.close();
   }
}
