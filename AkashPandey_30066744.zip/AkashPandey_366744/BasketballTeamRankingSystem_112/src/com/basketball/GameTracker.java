package com.basketball;
public interface GameTracker {
	   void addMatch(String team1, String team2, String score);
	   String findFirst();
	}