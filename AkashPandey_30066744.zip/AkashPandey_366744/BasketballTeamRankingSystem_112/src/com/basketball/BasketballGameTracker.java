package com.basketball;
import java.util.*;
public class BasketballGameTracker implements GameTracker {
   private final Map<String, Integer> teamScores;
   private final PriorityQueue<Map.Entry<String, Integer>> maxHeap;
   public BasketballGameTracker(String[] teamNames) {
       teamScores = new HashMap<>();
       for (String team : teamNames) {
           teamScores.put(team, 0);
       }
       // Max-Heap based on scores (entries are team -> score)
       maxHeap = new PriorityQueue<>(
           (a, b) -> b.getValue().compareTo(a.getValue())
       );
       maxHeap.addAll(teamScores.entrySet());
   }
   @Override
   public void addMatch(String team1, String team2, String score) {
       String[] scores = score.split(":");
       int score1 = Integer.parseInt(scores[0]);
       int score2 = Integer.parseInt(scores[1]);
       // Update scores in the map
       teamScores.put(team1, teamScores.getOrDefault(team1, 0) + score1);
       teamScores.put(team2, teamScores.getOrDefault(team2, 0) + score2);
       // Add updated entries to heap
       maxHeap.offer(Map.entry(team1, teamScores.get(team1)));
       maxHeap.offer(Map.entry(team2, teamScores.get(team2)));
   }
   @Override
   public String findFirst() {
       while (!maxHeap.isEmpty()) {
           Map.Entry<String, Integer> top = maxHeap.peek();
           if (teamScores.get(top.getKey()).equals(top.getValue())) {
               return top.getKey(); // Current highest score team
           }
           maxHeap.poll(); // Outdated entry
       }
       return null; // Shouldn't happen unless no teams exist
   }
}