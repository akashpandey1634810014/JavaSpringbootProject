package com.basketball;
import java.util.*;
public class Main {
	   public static void main(String[] args) {
	       Scanner sc = new Scanner(System.in);
	       int n = Integer.parseInt(sc.nextLine());
	       String[] teamNames = new String[n];
	       for (int i = 0; i < n; i++) {
	           teamNames[i] = sc.nextLine();
	       }
	       BasketballGameTracker tracker = new BasketballGameTracker(teamNames);
	       int m = Integer.parseInt(sc.nextLine());
	       for (int i = 0; i < m; i++) {
	           String[] parts = sc.nextLine().split(" ");
	           String team1 = parts[0];
	           String team2 = parts[1];
	           String score = parts[2];
	           tracker.addMatch(team1, team2, score);
	       }
	       System.out.println(tracker.findFirst());
	   }
	}
			