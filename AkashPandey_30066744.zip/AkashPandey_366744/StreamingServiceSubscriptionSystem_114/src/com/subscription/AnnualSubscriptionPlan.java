package com.subscription;

public class AnnualSubscriptionPlan implements SubscriptionPlan {
	   @Override
	   public void subscribe(double fee) {
	       System.out.println("Subscribing to Annual Plan with a fee of $" + Utils.roundDouble(fee) + ".");
	       double cashback = fee * 0.05;
	       System.out.println("Earned a cashback of $" + Utils.roundDouble(cashback) + ".");
	   }
	}
