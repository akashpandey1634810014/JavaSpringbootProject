package com.subscription;
import java.text.DecimalFormat;
public class Utils {
   public static String roundDouble(double d) {
       DecimalFormat df = new DecimalFormat("#.00");
       return df.format(d);
   }
}
