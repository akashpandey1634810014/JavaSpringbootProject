package com.subscription;
public class MonthlySubscriptionPlan implements SubscriptionPlan {
	   @Override
	   public void subscribe(double fee) {
	       System.out.println("Subscribing to Monthly Plan with a fee of $" + Utils.roundDouble(fee) + ".");
	       double discount = 0.0;
	       if (fee > 50.0) {
	           discount = fee * 0.10;
	           System.out.println("Applied a discount of $" + Utils.roundDouble(discount) + ".");
	       }
	       double finalFee = fee - discount;
	       System.out.println("Final subscription fee is $" + Utils.roundDouble(finalFee) + ".");
	   }
	}
