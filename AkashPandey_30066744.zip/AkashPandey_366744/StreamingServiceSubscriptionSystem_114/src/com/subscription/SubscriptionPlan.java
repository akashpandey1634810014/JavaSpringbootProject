package com.subscription;
public interface SubscriptionPlan {
	   void subscribe(double fee);
	}