package com.subscription;

import java.util.*;
public class Main {
   public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
       int n = Integer.parseInt(scanner.nextLine());
       for (int i = 0; i < n; i++) {
           String[] parts = scanner.nextLine().split(" ");
           String type = parts[1]; // Monthly or Annual
           double fee = Double.parseDouble(parts[3]);
           SubscriptionPlan plan;
           if (type.equalsIgnoreCase("Monthly")) {
               plan = new MonthlySubscriptionPlan();
           } else {
               plan = new AnnualSubscriptionPlan();
           }
           plan.subscribe(fee);
       }
       scanner.close();
   }
}
