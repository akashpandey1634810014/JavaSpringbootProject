package com.team;
public class Main {
	   public static void main(String[] args) {
	       ResearchTeam researchTeam = new ResearchTeam();
	       researchTeam.calculateAvgExperience();
	       researchTeam.retireResearcher(3);
	       researchTeam.retireResearcher(3); // Try to retire again
	       researchTeam.transferResearcher(1, 5);
	       researchTeam.transferResearcher(0, 7);
	       System.out.println("\n--- Development Team ---");
	       DevelopmentTeam developmentTeam = new DevelopmentTeam();
	       developmentTeam.calculateAvgExperience();
	       developmentTeam.retireResearcher(10);
	       developmentTeam.transferResearcher(1, 2);
	   }
	}
