package com.team;
import java.util.Arrays;
public class ResearchTeam implements Team {
   private int[] researcherIDs;
   public ResearchTeam() {
       researcherIDs = new int[11];
       Arrays.fill(researcherIDs, 1); // Initialize all elements to 1
       System.out.println("A new research team has been formed.");
   }
   public void calculateAvgExperience() {
       // Sample experience data (replace with actual data retrieval)
       int[] experienceYears = {5, 8, 3, 10, 6, 7, 4, 9, 2, 11, 5};
       double sum = 0;
       for (int experience : experienceYears) {
           sum += experience;
       }
       double avgExperience = sum / experienceYears.length;
       System.out.printf("The average experience of the team is %.2f years.\n", avgExperience);
   }
   public void retireResearcher(int id) {
       if (id >= 1 && id <= researcherIDs.length) {
           if (researcherIDs[id - 1] == -1) {
               System.out.println("Researcher with id: " + id + " has already retired.");
           } else {
               researcherIDs[id - 1] = -1;
               System.out.println("Researcher with id: " + id + " has retired.");
           }
       } else {
           System.out.println("Invalid researcher ID.");
       }
   }
   public void transferResearcher(int fee, int id) {
       if (id >= 1 && id <= researcherIDs.length) {
           if (researcherIDs[id - 1] == -1) {
               System.out.println("Researcher with id: " + id + " has already retired.");
           } else if (fee == 1) {
               System.out.println("Researcher with id: " + id + " has been transferred with a fee of {" + fee + "}.");
               researcherIDs[id - 1] = -1; // Mark as retired after transfer
           } else {
               System.out.println("Transfer fee not met for researcher with id: " + id + ".");
           }
       } else {
           System.out.println("Invalid researcher ID.");
       }
   }
}
