package com.team;

public interface Team {
	void calculateAvgExperience();
	   void retireResearcher(int id);
	   void transferResearcher(int fee, int id);

}
