package com.example.taskmanagement;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
@RestController
@RequestMapping("/v1/tasks")
public class TaskController {
   private final List<Task> tasks = new ArrayList<>();
   private final AtomicLong idCounter = new AtomicLong();
   // 1. Create a new task
   @PostMapping
   public ResponseEntity<Task> createTask(@RequestBody Task task) {
       Task newTask = new Task();
       newTask.setId(idCounter.incrementAndGet());
       newTask.setTitle(task.getTitle());
       newTask.setDescription(task.getDescription());
       newTask.setPriority(task.getPriority());
       tasks.add(newTask);
       return ResponseEntity.status(HttpStatus.CREATED).body(newTask);
   }
   // 2. Get all tasks ordered by id
   @GetMapping
   public ResponseEntity<List<Task>> getAllTasks() {
       List<Task> sortedTasks = new ArrayList<>(tasks);
       sortedTasks.sort(Comparator.comparing(Task::getId));
       return ResponseEntity.ok(sortedTasks);
   }
   // 3. Get a specific task by id
   @GetMapping("/{taskId}")
   public ResponseEntity<Task> getTaskById(@PathVariable Long taskId) {
       Task task = tasks.stream()
               .filter(t -> t.getId().equals(taskId))
               .findFirst()
               .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Task not found"));
       return ResponseEntity.ok(task);
   }
   // 4. Delete a task by id
   @DeleteMapping("/{taskId}")
   public ResponseEntity<Void> deleteTask(@PathVariable Long taskId) {
       boolean removed = tasks.removeIf(task -> task.getId().equals(taskId));
       if (!removed) {
           throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Task not found");
       }
       return ResponseEntity.noContent().build();
   }
}
