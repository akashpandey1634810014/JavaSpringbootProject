package com.operations;

import java.util.*;
public interface HospitalInventory {
   void addPatient(IPatient patient);
   void removePatient(IPatient patient);
   int calculateTotalBill();
   List<IPatient> getPatientsByDisease(String disease);
   Map<Integer, List<IPatient>> getPatientsByAge();
   List<AgeGroup> getPatientsByAgeRange();
}
