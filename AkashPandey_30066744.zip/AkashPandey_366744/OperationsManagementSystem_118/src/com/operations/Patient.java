package com.operations;

public class Patient implements IPatient {
	   private String name;
	   private int age;
	   private String gender;
	   private String disease;
	   private int bill;
	   public Patient(String name, int age, String gender, String disease, int bill) {
	       this.name = name;
	       this.age = age;
	       this.gender = gender;
	       this.disease = disease;
	       this.bill = bill;
	   }
	   public String getName() { return name; }
	   public int getAge() { return age; }
	   public String getGender() { return gender; }
	   public String getDisease() { return disease; }
	   public int getBill() { return bill; }
	   @Override
	   public String toString() {
	       return name + "-" + age + "-" + disease + "-" + bill;
	   }
	}
