package com.operations;

public interface IPatient {
	   String getName();
	   int getAge();
	   String getGender();
	   String getDisease();
	   int getBill();
	}
