package com.operations;

public class Main {
	   public static void main(String[] args) {
	       HospitalInventory inventory = new HospitalInventoryImpl();
	       IPatient p1 = new Patient("John", 35, "Male", "Flu", 1500);
	       IPatient p2 = new Patient("Alice", 45, "Female", "Diabetes", 2500);
	       IPatient p3 = new Patient("Bob", 25, "Male", "Flu", 1800);
	       inventory.addPatient(p1);
	       inventory.addPatient(p2);
	       inventory.addPatient(p3);
	       System.out.println("Patients by Disease:");
	       System.out.println("Flu: " + inventory.getPatientsByDisease("Flu"));
	       System.out.println("Diabetes: " + inventory.getPatientsByDisease("Diabetes"));
	       System.out.println("\nPatients by Age:");
	       inventory.getPatientsByAge().forEach((age, list) -> {
	           System.out.println(age + ": " + list);
	       });
	       System.out.println("\nPatients by Age Range:");
	       for (AgeGroup group : inventory.getPatientsByAgeRange()) {
	           System.out.println(group);
	       }
	       System.out.println("\nTotal Bill: " + inventory.calculateTotalBill());
	   }
	}
