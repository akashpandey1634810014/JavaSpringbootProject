package com.operations;

import java.util.*;
import java.util.stream.Collectors;
public class HospitalInventoryImpl implements HospitalInventory {
   private List<IPatient> patients = new ArrayList<>();
   public void addPatient(IPatient patient) {
       patients.add(patient);
   }
   public void removePatient(IPatient patient) {
       patients.remove(patient);
   }
   public int calculateTotalBill() {
       return patients.stream().mapToInt(IPatient::getBill).sum();
   }
   public List<IPatient> getPatientsByDisease(String disease) {
       return patients.stream()
               .filter(p -> p.getDisease().equalsIgnoreCase(disease))
               .sorted(Comparator.comparing(IPatient::getName))
               .collect(Collectors.toList());
   }
   public Map<Integer, List<IPatient>> getPatientsByAge() {
       return patients.stream()
               .collect(Collectors.groupingBy(IPatient::getAge,
                       Collectors.collectingAndThen(Collectors.toList(),
                               list -> list.stream()
                                       .sorted(Comparator.comparing(IPatient::getName))
                                       .collect(Collectors.toList()))));
   }
   public List<AgeGroup> getPatientsByAgeRange() {
       List<AgeGroup> groups = new ArrayList<>();
       groups.add(getGroup(0, 20));
       groups.add(getGroup(21, 40));
       groups.add(getGroup(41, 60));
       return groups;
   }
   private AgeGroup getGroup(int start, int end) {
       List<IPatient> group = patients.stream()
               .filter(p -> p.getAge() >= start && p.getAge() <= end)
               .sorted(Comparator.comparing(IPatient::getName))
               .collect(Collectors.toList());
       return new AgeGroup(start, end, group);
   }
}
