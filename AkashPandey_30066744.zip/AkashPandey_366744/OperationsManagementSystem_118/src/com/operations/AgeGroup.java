package com.operations;

import java.util.List;
public class AgeGroup {
   private int startAge;
   private int endAge;
   private List<IPatient> patients;
   public AgeGroup(int startAge, int endAge, List<IPatient> patients) {
       this.startAge = startAge;
       this.endAge = endAge;
       this.patients = patients;
   }
   public int getStartAge() { return startAge; }
   public int getEndAge() { return endAge; }
   public List<IPatient> getPatients() { return patients; }
   @Override
   public String toString() {
       return startAge + "-" + endAge + ": " + patients.toString();
   }
}
