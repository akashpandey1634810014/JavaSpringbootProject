package com.upi;

import java.util.*;
public class Main {
   public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       Map<String, UPIAccount> accountMap = new HashMap<>();
       UPITransaction transactionHandler = new UPITransaction();
       int n = Integer.parseInt(sc.nextLine());
       for (int i = 0; i < n; i++) {
           String[] input = sc.nextLine().split(" ");
           String accId = input[0];
           String username = input[1];
           UPIAccount account;
           if (input.length == 3) {
               String token = input[2];
               account = new UPIAccount(accId, username, token);
           } else {
               account = new UPIAccount(accId, username);
           }
           accountMap.put(accId, account);
       }
       int transactionCount = Integer.parseInt(sc.nextLine());
       for (int i = 0; i < transactionCount; i++) {
           String[] trans = sc.nextLine().split(" ");
           String accId = trans[0];
           String type = trans[1];
           int amount = Integer.parseInt(trans[2]);
           UPIAccount acc = accountMap.get(accId);
           try {
               if (type.equals("add")) {
                   transactionHandler.addMoney(acc, amount);
               } else if (type.equals("pay")) {
                   transactionHandler.payMoney(acc, amount);
               }
           } catch (TransactionException e) {
               System.out.println(e.getErrorCode() + ": " + e.getMessage());
           }
       }
       for (UPIAccount acc : accountMap.values()) {
           System.out.println(acc.getAccountId() + " " + acc.getAccountBalance());
       }
       sc.close();
   }
}
