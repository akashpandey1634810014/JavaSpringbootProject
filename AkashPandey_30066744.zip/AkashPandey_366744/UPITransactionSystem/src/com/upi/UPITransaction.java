package com.upi;

public class UPITransaction {

    public void addMoney(UPIAccount upiAccount, int amount) throws TransactionException {

        if (upiAccount.getUserAccessToken() == null) {

            throw new TransactionException("User not authorized.", "USER_NOT_AUTHORIZED");

        }

        if (amount <= 0) {

            throw new TransactionException("Amount should be greater than zero.", "INVALID_AMOUNT");

        }

        upiAccount.setAccountBalance(upiAccount.getAccountBalance() + amount);

        System.out.println("Account successfully credited.");

    }

    public void payMoney(UPIAccount upiAccount, int amount) throws TransactionException {

        if (upiAccount.getUserAccessToken() == null) {

            throw new TransactionException("User not authorized.", "USER_NOT_AUTHORIZED");

        }

        if (amount <= 0) {

            throw new TransactionException("Amount should be greater than zero.", "INVALID_AMOUNT");

        }

        if (upiAccount.getAccountBalance() < amount) {

            throw new TransactionException("Insufficient balance.", "INSUFFICIENT_BALANCE");

        }

        upiAccount.setAccountBalance(upiAccount.getAccountBalance() - amount);

        System.out.println("Account successfully debited.");

    }

}
 
