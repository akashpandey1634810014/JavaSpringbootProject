package com.upi;

public class UPIAccount {
	   private String accountId;
	   private String userName;
	   private String userAccessToken;
	   private int accountBalance;
	   public UPIAccount(String accountId, String userName) {
	       this.accountId = accountId;
	       this.userName = userName;
	       this.userAccessToken = null;
	       this.accountBalance = 0;
	   }
	   public UPIAccount(String accountId, String userName, String userAccessToken) {
	       this.accountId = accountId;
	       this.userName = userName;
	       this.userAccessToken = userAccessToken;
	       this.accountBalance = 0;
	   }
	   public String getAccountId() {
	       return accountId;
	   }
	   public String getUsername() {
	       return userName;
	   }
	   public String getUserAccessToken() {
	       return userAccessToken;
	   }
	   public int getAccountBalance() {
	       return accountBalance;
	   }
	   public void setAccountBalance(int accountBalance) {
	       this.accountBalance = accountBalance;
	   }
	}
