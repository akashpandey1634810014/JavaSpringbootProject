package com.carbuilder;

import java.util.Scanner;
public class Main {
   public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       int n = Integer.parseInt(sc.nextLine());
       for (int i = 0; i < n; i++) {
           String[] temp = sc.nextLine().split(" ");
           String make = temp[0];
           String model = temp[1];
           boolean isElectric = Boolean.parseBoolean(temp[2]);
           boolean hasSunroof = Boolean.parseBoolean(temp[3]);
           int horsepower = Integer.parseInt(temp[4]);
           int doors = Integer.parseInt(temp[5]);
           Car car = new Car.CarBuilder(make, model)
                           .setElectric(isElectric)
                           .setSunroof(hasSunroof)
                           .setHorsepower(horsepower)
                           .setDoors(doors)
                           .build();
           car.printDetails();
       }
   }
}
