package com.carbuilder;

public class Car {
	   private Boolean isElectric;
	   private Boolean hasSunroof;
	   private Integer horsepower;
	   private Integer doors;
	   private String make;
	   private String model;
	   public Car(CarBuilder builder) {
	       this.isElectric = builder.isElectric;
	       this.hasSunroof = builder.hasSunroof;
	       this.horsepower = builder.horsepower;
	       this.doors = builder.doors;
	       this.make = builder.make;
	       this.model = builder.model;
	   }
	   public Boolean isElectric() {
	       return isElectric;
	   }
	   public Boolean hasSunroof() {
	       return hasSunroof;
	   }
	   public Integer getHorsepower() {
	       return horsepower;
	   }
	   public Integer getDoors() {
	       return doors;
	   }
	   public String getMake() {
	       return make;
	   }
	   public String getModel() {
	       return model;
	   }
	   public void printDetails() {
	       System.out.println("Car " + model + " of make " + make + " with following features: electric " + isElectric
	               + ", sunroof " + hasSunroof + ", horsepower " + horsepower + ", doors " + doors + ".");
	   }
	   public static class CarBuilder {
	       private Boolean isElectric;
	       private Boolean hasSunroof;
	       private Integer horsepower;
	       private Integer doors;
	       private String make;
	       private String model;
	       public CarBuilder(String make, String model) {
	           this.make = make;
	           this.model = model;
	       }
	       public CarBuilder setElectric(Boolean isElectric) {
	           this.isElectric = isElectric;
	           return this;
	       }
	       public CarBuilder setSunroof(Boolean hasSunroof) {
	           this.hasSunroof = hasSunroof;
	           return this;
	       }
	       public CarBuilder setHorsepower(Integer horsepower) {
	           this.horsepower = horsepower;
	           return this;
	       }
	       public CarBuilder setDoors(Integer doors) {
	           this.doors = doors;
	           return this;
	       }
	       public Car build() {
	           return new Car(this);
	       }
	   }
	}
