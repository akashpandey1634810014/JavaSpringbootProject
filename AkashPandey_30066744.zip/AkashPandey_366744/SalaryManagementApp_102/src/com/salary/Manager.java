package com.salary;

public class Manager implements Employee {

    protected float basicSalary;

    protected float bonus;

    public Manager(float new_basicSalary, float new_bonus) {

        this.basicSalary = new_basicSalary;

        this.bonus = new_bonus;

    }

    @Override

    public float calculateSalary() {

        System.out.println("Calculating salary of manager with basicSalary = " + basicSalary + " and bonus = " + bonus);

        return basicSalary + bonus;

    }

    @Override

    public float calculateBenefits() {

        System.out.println("Calculating benefits of manager with basicSalary = " + basicSalary);

        return 0.2f * basicSalary;

    }

    @Override

    public String toString() {

        float salary = calculateSalary();

        float benefits = calculateBenefits();

        return "Manager = [basicSalary: " + basicSalary + ", bonus: " + bonus + ", salary: " + salary + ", benefits: " + benefits + "]";

    }

}
 
