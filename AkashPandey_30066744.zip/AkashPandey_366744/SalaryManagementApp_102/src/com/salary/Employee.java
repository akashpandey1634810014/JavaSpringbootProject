package com.salary;

public interface Employee {
	float calculateSalary();
	   float calculateBenefits();
	   String toString();

}
