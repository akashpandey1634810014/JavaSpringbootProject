package com.salary;

public class Main {
	   public static void main(String[] args) {
	       Manager manager = new Manager(5000, 2000);
	       System.out.println(manager);
	       Engineer engineer = new Engineer(4000);
	       System.out.println(engineer);
	       Intern intern = new Intern(1500);
	       System.out.println(intern);
	   }
	}
