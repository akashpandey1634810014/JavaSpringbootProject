package com.salary;

public class Intern implements Employee {

    private float stipend;

    public Intern(float new_stipend) {

        this.stipend = new_stipend;

    }

    @Override

    public float calculateSalary() {

        System.out.println("Calculating salary of intern with stipend = " + stipend);

        return stipend;

    }

    @Override

    public float calculateBenefits() {

        System.out.println("Calculating benefits of intern with stipend = " + stipend);

        return 0.0f;

    }

    @Override

    public String toString() {

        float salary = calculateSalary();

        float benefits = calculateBenefits();

        return "Intern = [stipend: " + stipend + ", salary: " + salary + ", benefits: " + benefits + "]";

    }

}
 
