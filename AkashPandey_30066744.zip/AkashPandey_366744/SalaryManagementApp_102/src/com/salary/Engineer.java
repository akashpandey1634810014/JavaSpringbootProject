package com.salary;

public class Engineer extends Manager {

    public Engineer(float basicSalary) {

        super(basicSalary, 0);  // Engineer has no bonus

    }

    @Override

    public float calculateSalary() {

        System.out.println("Calculating salary of engineer with basicSalary = " + basicSalary);

        return basicSalary;

    }

    @Override

    public float calculateBenefits() {

        System.out.println("Calculating benefits of engineer with basicSalary = " + basicSalary);

        return 0.15f * basicSalary;

    }

    @Override

    public String toString() {

        float salary = calculateSalary();

        float benefits = calculateBenefits();

        return "Engineer = [basicSalary: " + basicSalary + ", salary: " + salary + ", benefits: " + benefits + "]";

    }

}
 
