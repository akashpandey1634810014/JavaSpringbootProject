package com.vehicle;

class Truck implements Vehicle {
	   private int[] parts;
	   public Truck(int n) {
	       parts = new int[n];
	       for (int i = 0; i < n; i++) {
	           parts[i] = 0;
	       }
	       System.out.println("A truck is being constructed");
	   }
	   public void assemblePart(int partNumber) {
	       if (partNumber <= parts.length && partNumber > 0) {
	           parts[partNumber - 1] = 1;
	           System.out.println("Assembly for part number " + partNumber + " completed in truck");
	       } else {
	           System.out.println("Part number " + partNumber + " does not exist in truck");
	       }
	   }
	   public void printPartStatus(int partNumber) {
	       if (partNumber <= parts.length && partNumber > 0) {
	           if (parts[partNumber - 1] == 1) {
	               System.out.println("Assembly for part number " + partNumber + " completed in truck");
	           } else {
	               System.out.println("Assembly for part number " + partNumber + " not completed in truck");
	           }
	       } else {
	           System.out.println("Part number " + partNumber + " does not exist in truck");
	       }
	   }
	   public void printTotalParts() {
	       System.out.println("The truck has " + parts.length + " parts");
	   }
	}
