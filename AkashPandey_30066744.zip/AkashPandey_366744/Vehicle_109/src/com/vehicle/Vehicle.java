package com.vehicle;
interface Vehicle {
	   void assemblePart(int partNumber);
	   void printPartStatus(int partNumber);
	   void printTotalParts();
	}
