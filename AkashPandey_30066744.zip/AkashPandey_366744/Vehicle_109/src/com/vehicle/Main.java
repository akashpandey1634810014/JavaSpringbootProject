package com.vehicle;

import java.util.*;
public class Main {
   public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       int n = sc.nextInt(); // parts in car
       int m = sc.nextInt(); // parts in truck
       sc.nextLine();
       Car car = new Car(n);
       Truck truck = new Truck(m);
       // Car - assemble
       String[] carAssemble = sc.nextLine().split(" ");
       for (String s : carAssemble) {
           car.assemblePart(Integer.parseInt(s));
       }
       // Car - status
       String[] carStatus = sc.nextLine().split(" ");
       for (String s : carStatus) {
           car.printPartStatus(Integer.parseInt(s));
       }
       car.printTotalParts();
       // Truck - assemble
       String[] truckAssemble = sc.nextLine().split(" ");
       for (String s : truckAssemble) {
           truck.assemblePart(Integer.parseInt(s));
       }
       // Truck - status
       String[] truckStatus = sc.nextLine().split(" ");
       for (String s : truckStatus) {
           truck.printPartStatus(Integer.parseInt(s));
       }
       truck.printTotalParts();
   }
}
