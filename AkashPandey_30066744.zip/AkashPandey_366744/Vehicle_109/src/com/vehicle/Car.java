package com.vehicle;

class Car implements Vehicle {

    private int[] parts;

    public Car(int n) {

        parts = new int[n];

        for (int i = 0; i < n; i++) {

            parts[i] = 0;

        }

        System.out.println("A car is being constructed");

    }

    public void assemblePart(int partNumber) {

        if (partNumber <= parts.length && partNumber > 0) {

            parts[partNumber - 1] = 1;

            System.out.println("Assembly for part number " + partNumber + " completed in car");

        } else {

            System.out.println("Part number " + partNumber + " does not exist in car");

        }

    }

    public void printPartStatus(int partNumber) {

        if (partNumber <= parts.length && partNumber > 0) {

            if (parts[partNumber - 1] == 1) {

                System.out.println("Assembly for part number " + partNumber + " completed in car");

            } else {

                System.out.println("Assembly for part number " + partNumber + " not completed in car");

            }

        } else {

            System.out.println("Part number " + partNumber + " does not exist in car");

        }

    }

    public void printTotalParts() {

        System.out.println("The car has " + parts.length + " parts");

    }

}
 
