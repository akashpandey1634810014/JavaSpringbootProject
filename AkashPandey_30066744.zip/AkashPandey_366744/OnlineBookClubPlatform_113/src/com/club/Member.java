package com.club;

import java.util.HashSet;
import java.util.Set;
public class Member {
   private int id;
   private String name;
   private Set<Member> followers;
   private Set<Member> following;
   public Member(int id, String name) {
this.id = id;
       this.name = name;
       this.followers = new HashSet<>();
       this.following = new HashSet<>();
   }
   public String getName() {
       return name;
   }
   public void update(String bookTitle, Member recommender) {
       System.out.println(this.name + " received a recommendation: " + recommender.getName() + " recommended: \"" + bookTitle + "\".");
   }
   public void addFollowers(Member member) {
       followers.add(member);
   }
   public void removeFollowers(Member member) {
       followers.remove(member);
   }
   public void notifyFollowers(String bookTitle) {
       for (Member follower : followers) {
           follower.update(bookTitle, this);
       }
   }
   public void recommend(String bookTitle) {
       System.out.println(this.name + " recommended: \"" + bookTitle + "\"!");
       notifyFollowers(bookTitle);
   }
   public void follow(Member member) {
       if (following.contains(member)) return;
       following.add(member);
       member.addFollowers(this);
   }
   public void unfollow(Member member) {
       if (!following.contains(member)) return;
       following.remove(member);
       member.removeFollowers(this);
   }
}
