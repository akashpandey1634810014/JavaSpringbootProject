package com.club;
import java.util.Scanner;
public class Main {
   public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       BookClub club = new BookClub();
       int n = Integer.parseInt(sc.nextLine());
       for (int i = 0; i < n; i++) {
           String input = sc.nextLine();
           String[] parts = input.split(" ", 3);
           switch (parts[0]) {
               case "AddMember":
                   int id = Integer.parseInt(parts[1]);
                   String name = parts[2];
                   club.addMember(id, name);
                   break;
               case "RemoveMember":
                   club.removeMember(Integer.parseInt(parts[1]));
                   break;
               case "Follow":
                   String[] fparts = parts[1].split(" ");
                   club.follow(Integer.parseInt(fparts[0]), Integer.parseInt(fparts[1]));
                   break;
               case "Unfollow":
                   String[] uparts = parts[1].split(" ");
                   club.unfollow(Integer.parseInt(uparts[0]), Integer.parseInt(uparts[1]));
                   break;
               case "RecommendBook":
                   int mid = Integer.parseInt(parts[1]);
                   String title = parts[2].replace("\"", "");
                   club.recommendBook(mid, title);
                   break;
           }
       }
       sc.close();
   }
}
