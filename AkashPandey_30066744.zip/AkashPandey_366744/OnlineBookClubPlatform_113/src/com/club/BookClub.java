package com.club;

import java.util.HashMap;
import java.util.Map;
public class BookClub {
   private Map<Integer, Member> members;
   public BookClub() {
       members = new HashMap<>();
   }
   public void addMember(Integer id, String name) {
       if (!members.containsKey(id)) {
           members.put(id, new Member(id, name));
           System.out.println(name + " joined the book club.");
       }
   }
   public void removeMember(Integer id) {
       Member member = members.get(id);
       if (member != null) {
           System.out.println(member.getName() + " left the book club.");
           members.remove(id);
       }
   }
   public void follow(Integer followerId, Integer followeeId) {
       Member follower = members.get(followerId);
       Member followee = members.get(followeeId);
       if (follower != null && followee != null && follower != followee) {
           follower.follow(followee);
           System.out.println(follower.getName() + " is now following " + followee.getName() + ".");
       }
   }
   public void unfollow(Integer followerId, Integer followeeId) {
       Member follower = members.get(followerId);
       Member followee = members.get(followeeId);
       if (follower != null && followee != null && follower != followee) {
           follower.unfollow(followee);
           System.out.println(follower.getName() + " has unfollowed " + followee.getName() + ".");
       }
   }
   public void recommendBook(Integer memberId, String bookTitle) {
       Member member = members.get(memberId);
       if (member != null) {
           member.recommend(bookTitle);
       }
   }
}