package com.safebank;

public class FixedDepositAccount extends Account {
	   public void manage(String accountHolderName) {
	       System.out.println("Managing account for " + accountHolderName + "(FixedDeposit)");
	   }
	}
