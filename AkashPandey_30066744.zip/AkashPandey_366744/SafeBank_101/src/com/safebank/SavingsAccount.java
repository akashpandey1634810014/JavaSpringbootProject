package com.safebank;

public class SavingsAccount extends Account {
	   public void manage(String accountHolderName) {
	       System.out.println("Managing account for " + accountHolderName + "(Savings)");
	   }
	}
