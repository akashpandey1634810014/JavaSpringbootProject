package com.safebank;

public class Main {
	   public static void main(String[] args) {
	       AccountFactory factory = AccountFactory.getFactory();
	       // Registering valid account types
	       factory.registerAccount("Savings", new SavingsAccount());
	       factory.registerAccount("Current", new CurrentAccount());
	       factory.registerAccount("FixedDeposit", new FixedDepositAccount());
	       factory.registerAccount("Loan", new LoanAccount());
	       // Sample inputs
	       String[][] requests = {
	           {"Savings", "JohnDoe"},
	           {"Loan", "JaneSmith"},
	           {"Crypto", "AliceGreen"} // Invalid
	       };
	       for (String[] request : requests) {
	           String key = request[0];
	           String holder = request[1];
	           try {
	               factory.manageAccount(key, holder);
	           } catch (UnmanageableAccountRequestException e) {
	               System.out.println(e.getMessage());
	           }
	       }
	   }
	}
