package com.safebank;

import java.util.HashMap;
import java.util.Map;
public class AccountFactory {
   private static AccountFactory instance = null;
   private Map<String, Account> registeredAccounts;
   private AccountFactory() {
       registeredAccounts = new HashMap<>();
   }
   public static AccountFactory getFactory() {
       if (instance == null) {
           instance = new AccountFactory();
       }
       return instance;
   }
   public void registerAccount(String accountKey, Account account) {
       registeredAccounts.put(accountKey, account);
   }
   public void manageAccount(String accountKey, String accountHolderName) throws UnmanageableAccountRequestException {
       if (!registeredAccounts.containsKey(accountKey)) {
           throw new UnmanageableAccountRequestException("Unmanageable account " + accountKey + " for holder " + accountHolderName);
       }
       registeredAccounts.get(accountKey).manage(accountHolderName);
   }
}
