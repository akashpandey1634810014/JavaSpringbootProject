package com.safebank;

public abstract class Account {
	public abstract void manage(String accountHolderName);
	}


