package com.safebank;

public class CurrentAccount extends Account {
	   public void manage(String accountHolderName) {
	       System.out.println("Managing account for " + accountHolderName + "(Current)");
	   }
	}
