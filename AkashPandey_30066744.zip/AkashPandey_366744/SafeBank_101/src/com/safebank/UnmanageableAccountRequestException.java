package com.safebank;

public class UnmanageableAccountRequestException extends Exception {
	   public UnmanageableAccountRequestException(String message) {
	       super(message);
	   }
	}
