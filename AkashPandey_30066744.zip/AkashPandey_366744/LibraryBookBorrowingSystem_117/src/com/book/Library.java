package com.book;
import java.util.List;
import java.util.Map;
public interface Library {
   void addBook(IBook book, int quantity);
   void borrowBook(IBook book, int quantity);
   void returnBook(IBook book, int quantity);
   int totalBooksBorrowed();
   Map<String, Integer> booksByGenre();
   List<String> borrowedBooksDetails();
}
