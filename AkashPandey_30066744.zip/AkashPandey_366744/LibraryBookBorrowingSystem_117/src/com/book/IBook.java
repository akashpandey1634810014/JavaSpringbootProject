package com.book;
public interface IBook {
	   int getId();
	   String getTitle();
	   String getAuthor();
	   String getGenre();
	}
