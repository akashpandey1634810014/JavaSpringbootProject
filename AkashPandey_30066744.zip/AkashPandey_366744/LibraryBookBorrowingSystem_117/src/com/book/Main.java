package com.book;
public class Main {
	   public static void main(String[] args) {
	       Library library = new LibraryImpl();
	       IBook book1 = new Book(1, "The Great Gatsby", "F. Scott Fitzgerald", "Fiction");
	       IBook book2 = new Book(2, "A Brief History of Time", "Stephen Hawking", "Science");
	       IBook book3 = new Book(3, "1984", "George Orwell", "Fiction");
	       library.addBook(book1, 10);
	       library.addBook(book2, 5);
	       library.addBook(book3, 8);
	       library.borrowBook(book1, 3);
	       library.borrowBook(book2, 2);
	       library.borrowBook(book3, 1);
	       System.out.println("Total Books Borrowed: " + library.totalBooksBorrowed());
	       System.out.println("\nBooks by Genre:");
	       library.booksByGenre().forEach((genre, count) ->
	           System.out.println(genre + ": " + count)
	       );
	       System.out.println("\nBorrowed Books:");
	       for (String detail : library.borrowedBooksDetails()) {
	           System.out.println(detail);
	       }
	   }
	}
