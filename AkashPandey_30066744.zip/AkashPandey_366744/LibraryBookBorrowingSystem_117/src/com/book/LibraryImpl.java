package com.book;
import java.util.*;
public class LibraryImpl implements Library {
   private Map<IBook, Integer> inventory = new HashMap<>();
   private Map<IBook, Integer> borrowed = new HashMap<>();
   @Override
   public void addBook(IBook book, int quantity) {
       inventory.put(book, inventory.getOrDefault(book, 0) + quantity);
   }
   @Override
   public void borrowBook(IBook book, int quantity) {
       int available = inventory.getOrDefault(book, 0);
       if (available >= quantity) {
           inventory.put(book, available - quantity);
           borrowed.put(book, borrowed.getOrDefault(book, 0) + quantity);
       } else {
           System.out.println("Not enough copies available for: " + book.getTitle());
       }
   }
   @Override
   public void returnBook(IBook book, int quantity) {
       borrowed.put(book, borrowed.getOrDefault(book, 0) - quantity);
       inventory.put(book, inventory.getOrDefault(book, 0) + quantity);
   }
   @Override
   public int totalBooksBorrowed() {
       return borrowed.values().stream().mapToInt(Integer::intValue).sum();
   }
   @Override
   public Map<String, Integer> booksByGenre() {
       Map<String, Integer> genreCount = new HashMap<>();
       for (Map.Entry<IBook, Integer> entry : borrowed.entrySet()) {
           String genre = entry.getKey().getGenre();
           genreCount.put(genre, genreCount.getOrDefault(genre, 0) + entry.getValue());
       }
       return genreCount;
   }
   @Override
   public List<String> borrowedBooksDetails() {
       List<String> details = new ArrayList<>();
       for (Map.Entry<IBook, Integer> entry : borrowed.entrySet()) {
           IBook book = entry.getKey();
           int quantity = entry.getValue();
           details.add(String.format("\"%s\" by %s (%s) - %d copies",
               book.getTitle(), book.getAuthor(), book.getGenre(), quantity));
       }
       return details;
   }
}
