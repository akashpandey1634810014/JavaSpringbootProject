package com.operations;

public class NumericDataType<T extends Number> implements MathOperations<T> {

    @Override

    public void addition(T a, T b) {

        System.out.println("Adding two numbers");

        double result = a.doubleValue() + b.doubleValue();

        System.out.printf("The result is: %.2f%n", result);

    }

    @Override

    public void subtraction(T a, T b) {

        System.out.println("Subtracting two numbers");

        double result = a.doubleValue() - b.doubleValue();

        System.out.printf("The result is: %.2f%n", result);

    }

    @Override

    public void multiplication(T a, T b) {

        System.out.println("Multiplying two numbers");

        double result = a.doubleValue() * b.doubleValue();

        System.out.printf("The result is: %.2f%n", result);

    }

    @Override

    public void division(T a, T b) {

        System.out.println("Dividing two numbers");

        if (b.doubleValue() == 0) {

            System.out.println("The result is: Infinity");

        } else {

            double result = a.doubleValue() / b.doubleValue();

            System.out.printf("The result is: %.2f%n", result);

        }

    }

    @Override

    public void performAll(T a, T b) {

        addition(a, b);

        subtraction(a, b);

        multiplication(a, b);

        division(a, b);

    }

}
 
