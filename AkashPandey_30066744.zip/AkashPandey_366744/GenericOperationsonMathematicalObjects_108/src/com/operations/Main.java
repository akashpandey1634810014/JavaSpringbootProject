package com.operations;

public class Main {
	   public static void main(String[] args) {
	       NumericDataType<Integer> intOps = new NumericDataType<>();
	       intOps.performAll(10, 10);
	       NumericDataType<Long> longOps = new NumericDataType<>();
	       longOps.performAll(1000000000L, 500000000L);
	       NumericDataType<Double> doubleOps = new NumericDataType<>();
	       doubleOps.performAll(3.14, 1.59);
	       StringDataType<String> stringOps = new StringDataType<>();
	       stringOps.performAll("hello", "world");
	       stringOps.performAll("java", "python");
	   }
	}
